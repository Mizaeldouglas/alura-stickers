package com.mizael.apimizael;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiMizaelApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiMizaelApplication.class, args);
	}

}
